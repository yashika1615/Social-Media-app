module.exports ={
    mongoURI : 'mongodb://anuj:anuj@localhost:27017/node-prac',
    secretOrKey: 'secret'
}